package parte1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import java.util.Date;
import java.util.List;

@Entity(name = "CLIENTE")
public class Cliente {
	
	/*PK*/
	@Id
	private String dni;
	@ManyToMany
	private List<Cuenta> listaCuentas;

	/*Atributos*/	
	private String nombre;	
	private String apellidos;
	private String direccion;	
	private String email;
	private int telefono;
	private Date fechNacimiento;
	
	/**
	 * Metodo constructor vacio necesario
	 */
	public Cliente(){
	}
	
	/**
	* Metodo constructor de la clase
	*/
	public Cliente(String dni, String nombre, String apellidos, String direccion,
			String email, int telefono, Date fechNacimiento) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellidos= apellidos;
		this.direccion= direccion;
		this.email = email;
		this.telefono = telefono;
		this.fechNacimiento = fechNacimiento;
	}	
	
	/**
	 * Devuelve el dni del cliente
	 * @return int
	 */
	public String getDni()
	{
		return dni;
	}
	
	/**
	 * Define el dni del cliente
	 * @param dni
	 */
	public void setDni(String dni)
	{
		this.dni = dni;
	}

	
	/**
	 * Devuelve un listado de las cuentas del cliente
	 * @return List<Cuenta>
	 */
	public List<Cuenta> getListaCuentas() {
		return listaCuentas;
	}
	
	/**
	 * Define una lista de cuentas
	 * @param listaCuentas
	 */
	public void setListaCuentas(List<Cuenta> listaCuentas) {
		this.listaCuentas = listaCuentas;
	}
	
	/**
	 * Devuelve el nombre del cliente
	 * @return String
	 */
	public String getNombre() 
	{
		return nombre;
	}

	/**
	 * Define el nombre del cliente
	 * @param nombre
	 */
	public void setNombre(String nombre) 
	{
		this.nombre = nombre;
	}
	
	/**
	 * Devuelve los apellidos del cliente
	 * @return String
	 */
	public String getApellidos() 
	{
		return apellidos;
	}
	
	/**
	 * Define los apellidos del cliente
	 * @param apellidos
	 */
	public void setApellidos(String apellidos) 
	{
		this.apellidos = apellidos;
	}
	
	/**
	 * Devuelve la direccion del cliente
	 * @return String
	 */
	public String getDireccion() 
	{
		return direccion;
	}

	/**
	 * Define la direccion del cliente
	 * @param direccion
	 */
	public void setDireccion(String direccion) 
	{
		this.direccion = direccion;
	}
	
	/**
	 * Devuelve el email del cliente
	 * @return String
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Define el email del cliente
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Devuelve el telefono del cliente
	 * @return int
	 */
	public int getTelefono() {
		return telefono;
	}
	
	/**
	 * Define el telefono del cliente
	 * @param telefono
	 */
	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
	
	/**
	 * Devuelve la fecha de nacimiento del cliente
	 * @return Date
	 */
	public Date getFechaNacimiento() {
		return fechNacimiento;
	}	
	
	/**
	 * Define la fecha de nacimiento del cliente
	 */
	public void setFechaNacimiento(Date fechNacimiento) 
	{
		this.fechNacimiento = fechNacimiento;
	}
	
	/**
	 * Devuelve un String con los datos del cliente
	 */
	@Override
	public String toString() 
	{
		return("Dni: "+dni+", Nombre: "+nombre+", Apellidos: "+apellidos+
				", Direccion: "+direccion+", Telefono: "+telefono+", Fecha Nacmiento: "
				+fechNacimiento);
	
      
    }
}

