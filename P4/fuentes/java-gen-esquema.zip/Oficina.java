package parte1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

@Entity(name = "OFICINA")
public class Oficina 
{
	/*PK*/
	@Id
	private int codigo;
	@OneToMany(mappedBy="oficina")
	private List<Cuenta> listaCuentas;	
	@OneToMany(mappedBy="oficina")
	private List<Operacion> listaOperaciones;
	
	/*Atributos*/
	private String direccion;	
	private int telefono;	
	
	/**
	 * Metodo constructor vac�o 
	 */
	public Oficina(){
	}
	
	/**
	 * Metodo constructor de la clase
	 */
	public Oficina(int codigo, String direccion, int telefono){
		this.codigo = codigo;
		this.direccion = direccion;
		this.telefono = telefono;
	}
	
	/**
	 * Devuelve el codigo de la oficina
	 * @return int
	 */
	public int getIdOficina() 
	{
		return codigo;
	}
	
	/**
	 * Define el codigo de una oficina
	 * @param codigo
	 */
	public void setIdOficina(int codigo) 
	{
		this.codigo = codigo;
	}
	
	/**
	 * Devuelve una lista de cuentas de una oficina
	 * @return List<Cuentas>
	 */
	public List<Cuenta> getListaCuentas() {
		return listaCuentas;
	}
	
	/**
	 * Define una lista de cuentas de una oficina
	 * @param listaCuentas
	 */
	public void setListaCuentas(List<Cuenta> listaCuentas) {
		this.listaCuentas = listaCuentas;
	}
	
	/**
	 * Devuelve la lista de operaciones de una oficina
	 * @return List<Operacion>
	 */
	public List<Operacion> getListaOperaciones() {
		return listaOperaciones;
	}
	
	/**
	 * Define una lista de operaciones de una oficina
	 * @param listaOperaciones
	 */
	public void setListaOperaciones(List<Operacion> listaOperaciones) {
		this.listaOperaciones = listaOperaciones;
	}
	
	/**
	 * Devuelve la direccion de una oficina
	 * @return String
	 */
	public String getDireccion() 
	{
		return direccion;
	}
	
	/**
	 * Define la direccion de una oficina
	 * @param direccion
	 */
	public void setDireccion(String direccion) 
	{
		this.direccion = direccion;
	}
	
	/**
	 * Devuelve el telefono de una oficina
	 * @return int
	 */
	public int getTelefono() 
	{
		return telefono;
	}
	
	/**
	 * Define el telefono de una oficina
	 * @param telefono
	 */
	public void setTelefono(int telefono) 
	{
		this.telefono = telefono;
	}
	
	/**
	 * Devuelve un String con los datos de cuenta
	 */
	@Override
	public String toString() 
	{
		return("Codigo: "+codigo+", Direccion: "+direccion+", Telefono: "+telefono);
      
    }	

}


