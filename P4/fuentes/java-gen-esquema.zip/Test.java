package test;

import parte1.Cliente;
import parte1.Cuenta;
import parte1.Oficina;
import parte1.Operacion;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TestCliente 
{
	/* Metodo principal que inserta datos de prueba y prueba las consultas*/
	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("EjemploDeUnidadDePersistencia");
		
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction trans = em.getTransaction();
		
		trans.begin();

		Oficina oficina = new Oficina();
		oficina.setIdOficina(1234);
		oficina.setDireccion("Paseo Independencia, 2, 3º B");
		oficina.setTelefono(976652821);

		em.persist(oficina);

		Cliente cliente = new Cliente();
		cliente.setDni("73001517T");
		cliente.setNombre("Juan");
		cliente.setApellidos("Lolo Lulo");
		cliente.setDireccion("Gran Via, 17, 2º A");
		cliente.setEmail("PericodelosPalotes@unizar.es");
		cliente.setTelefono(612345678);
		cliente.setFechaNacimiento(new Date(1992,04,19));

		em.persist(cliente);

		Cliente cliente2 = new Cliente();
		cliente2.setDni("73001515G");
		cliente2.setNombre("Pedro");
		cliente2.setApellidos("Paco Paco");
		cliente2.setDireccion("Via Hispanidad, 15, 5º C");
		cliente2.setEmail("pedrico@unizar.es");
		cliente2.setTelefono(685274196);
		cliente2.setFechaNacimiento(new Date(1972,10,10));

		em.persist(cliente2);

		Cuenta cuenta = new Cuenta();
		cuenta.setNumCuenta("12345678901234567890");
		cuenta.setTipoC(0);
		cuenta.setInteres(0.1);
		cuenta.setFechaCreacion(new Date(1998,3,1));

		em.persist(cuenta);

		Cuenta cuenta2 = new Cuenta();
		cuenta2.setNumCuenta("12345678901234567891");
		cuenta2.setTipoC(1);
		cuenta2.setOficina(oficina);
		cuenta2.setFechaCreacion(new Date(1978,12,5));

		em.persist(cuenta2);

		List<Cuenta> cuentaList = new ArrayList<Cuenta>();
		List<Cuenta> cuentaList2 = new ArrayList<Cuenta>();

		cuentaList.add(cuenta);
		cliente.setListaCuentas(cuentaList);
		em.persist(cliente);

		cuentaList2.add(cuenta);
		cuentaList2.add(cuenta2);
		cliente2.setListaCuentas(cuentaList2);
		em.persist(cliente2);

		List<Cliente> clienteList = new ArrayList<Cliente>();
		List<Cliente> clienteList2 = new ArrayList<Cliente>();

		clienteList.add(cliente);
		clienteList.add(cliente2);
		cuenta.setListaClientes(clienteList);
		em.persist(cuenta);

		clienteList2.add(cliente2);
		cuenta2.setListaClientes(clienteList2);
		em.persist(cuenta2);


		Operacion op = new Operacion();
		op.setC(cuenta);
		op.setCantidad(200);
		op.setDescripcion("Pago del colegio");
		op.setFecha(new Date());
		op.setTipoOperacion(0);
		op.setOficina(oficina);

		em.persist(op);

		trans.commit();

		em.close();
		entityManagerFactory.close();
	}

}
