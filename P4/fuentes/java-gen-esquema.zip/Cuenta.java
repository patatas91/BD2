package parte1;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity(name = "CUENTA")
public class Cuenta 
{
	/*PK*/
	@Id
	private String nCuenta;
	@ManyToMany (mappedBy="listaCuentas")
	private List<Cliente> listaClientes;
	@ManyToOne
	private Oficina oficina;
	@OneToMany(mappedBy="cuenta")
	private List<Operacion> listaOperaciones;
	
	/*Atributos*/
	private Date fecha;	
	private double saldo;
	private int tipo_c;
	private double interes;

	/**
	 * Metodo constructor vac�o
	 */
	public Cuenta(){
	}
	
	/**
	 * M�todo constructor de la clase
	 */
	public Cuenta(String nCuenta, Date fecha, int tipo_c, double interes, Oficina oficina) {
		this.nCuenta = nCuenta;
		this.fecha = fecha;
		this.saldo=0;
		this.tipo_c= tipo_c;
		this.interes = interes;
		this.oficina = oficina;
	}
	
	/**
	 * Devuelve el numero de cuenta
	 * @return int
	 */
	public String getNumCuenta()
	{
		return nCuenta;
	}

	/**
	 * Define el numero de cuenta
	 */
	public void setNumCuenta(String nCuenta)
	{
		this.nCuenta = nCuenta;
	}
	
	/**
	 * Devuelve la lista de clientes de una cuenta
	 * @return List<Cliente>
	 */
	public List<Cliente> getListaClientes() {
		return listaClientes;
	}
	
	/**
	 * Define la lista de clientes de una cuenta
	 * @param listaClientes
	 */
	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}
	
	/**
	 * Devuelve la oficina de una cuenta
	 * @return Oficina
	 */
	public Oficina getOficina() {
		return oficina;
	}
	/**
	 * Define la oficina de una cuenta
	 * @param oficina
	 */
	public void setOficina(Oficina oficina) {
		this.oficina = oficina;
	}

	/**
	 * Devuelve un listado de las operaciones de cuenta
	 * @return List<Operacion>
	 */
	public List<Operacion> getListaOperaciones() {
		return listaOperaciones;
	}
	
	/**
	 * Define una lista de operaciones de una cuenta
	 * @param listaOperaciones
	 */
	public void setListaOperaciones(List<Operacion> listaOperaciones) {
		this.listaOperaciones = listaOperaciones;
	}
	
	/**
	 * Devuelve la fecha de creacion de una cuenta
	 * @return Date
	 */
	public Date getFechaCreacion() {
		return fecha;
	}
	
	/**
	 * Define la fecha de creacion de una cuenta
	 * @param fecha
	 */
	public void setFechaCreacion(Date fecha) 
	{
		this.fecha = fecha;
	}
	
	/**
	 * Devuelve el saldo de una cuenta
	 * @return double
	 */
	public double getSaldo() 
	{
		return saldo;
	}
	
	/**
	 * Define el saldo de una cuenta
	 * @param saldo
	 */
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	/**
	 * Devuelve el tipo de cuenta
	 * @return int
	 */
	public int getTipoCuenta() 
	{
		return tipo_c;
	}
	
	/**
	 * Define el tipo de cuenta
	 * @param tipo_c
	 */
	public void setTipoC(int tipo_c) 
	{
		this.tipo_c = tipo_c;
	}
	
	/**
	 * Devuelve el interes de una cuenta
	 * @return double
	 */
	public double getInteres() 
	{
		return interes;
	}
	
	/**
	 * Define el interes de una cuenta
	 * @param interes
	 */
	public void setInteres(double interes) 
	{
		this.interes = interes;
	}
	
	/**
	 * Devuelve un String con los datos de cuenta
	 */
	@Override
	public String toString() 
	{
		return("N� Cuenta: "+nCuenta+", Fecha creacion: "+fecha+", Saldo: "+saldo+
				", Tipo cuenta: "+tipo_c+", Interes: "+interes+", Id oficina: "
				+ oficina.getIdOficina());
	
      
    }	

}

