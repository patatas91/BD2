package parte1;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.util.Date;

@Entity(name = "OPERACION")
public class Operacion 
{
	/*PK*/
	@Id
	private int nOperacion;		
	@ManyToOne
	private Cuenta cuenta;	
	@ManyToOne
	private Oficina oficina;	

	/*Atributos*/	
	private Date fecha;
	private String descripcion;	
	private float cantidad;	
	private int tipo_o;
	private String destino;
	
	/**
	 * Metodo constructor vacio 
	 */
	public Operacion(){
	}
	
	/**
	 * Metodo constructor de la clase
	 */
	public Operacion(int nOperacion, Date fecha, String descripcion,
			float cantidad, int tipo_o, String destino) {
		
		this.nOperacion = nOperacion;
		this.fecha=fecha;
		this.descripcion=descripcion;
		this.cantidad=cantidad;
		this.tipo_o=tipo_o;
		this.destino=destino;		
	}
	
	/**
	 * Devuelve el numero de la operacion
	 * @return int
	 */
	public int getNumOperacion() {
		return nOperacion;
	}
	
	/**
	 * Define el numero de la operacion
	 * @param numOperacion
	 */
	public void setNumOperacion(int numOperacion) {
		this.nOperacion = numOperacion;
	}
	
	/**
	 * Devuelve la cuenta de la operacion
	 * @return
	 */
	public Cuenta getCuenta() {
		return cuenta;
	}
	
	/**
	 * Define la cuenta de la operacion
	 * @param cuenta
	 */
	public void setC(Cuenta cuenta) {
		this.cuenta = cuenta;
	}
	
	/**
	 * Devuelve la oficina de la operacion
	 * @return Oficina
	 */
	public Oficina getOficina() {
		return oficina;
	}
	
	/**
	 * Define la oficina de la operacion
	 * @param oficina
	 */
	public void setOficina(Oficina oficina) {
		this.oficina = oficina;
	}
	
	/**
	 * Devuelve la fecha de la operacion
	 * @return Date
	 */
	public Date getFecha() {
		return fecha;
	}
	
	/**
	 * Define la fecha de la operacion
	 * @param fecha
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	/**
	 * Devuelve la descripcion de una operacion
	 * @return String
	 */
	public String getDescripcion() {
		return descripcion;
	}
	
	/**
	 * Define la descripcion de una operacion
	 * @param descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	/**
	 * Devuelve la cantidad de una operacion
	 * @return float
	 */
	public float getCantidad() {
		return cantidad;
	}
	
	/**
	 * Define la cantidad de una operacion
	 * @param cantidad
	 */
	public void setCantidad(float cantidad) {
		this.cantidad = cantidad;
	}
	
	/**
	 * Devuelve el tipo de la operacion
	 * @return int
	 */
	public int getTipoOperacion() {
		return tipo_o;
	}
	
	/**
	 * Define el tipo de una operacion
	 */
	public void setTipoOperacion(int tipo_o) {
		this.tipo_o = tipo_o;
	}

	/**
	 * Devuelve el numero de cuenta de destino
	 * @return int
	 */
	public String getDestino() {
		return destino;
	}
	
	/**
	 * Define el numero de cuenta de destino
	 */
	public void setDestino(String destino) {
		this.destino = destino;
	}
	
	/**
	 * Devuelve un String con los datos de cuenta
	 */
	@Override
	public String toString() 
	{
		return("N� Operacion: "+nOperacion+", Descripcion: "+descripcion+", Fecha: "+fecha+
				", Hora: "+fecha.getTime()+", Cantidad: "+cantidad+", Tipo operacion: "+tipo_o+
				", Origen: "+cuenta.getNumCuenta()+", Destino: "+destino);
      
    }	
	
}
