package test;

import parte2.Cliente;
import parte2.Cuenta;
import parte2.Oficina;
import parte2.Operacion;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import java.util.*;

public class TestCliente 
{
	public static void main(String[] args) 
	{
		EntityManagerFactory entityManagerFactory =  Persistence.createEntityManagerFactory("EjemploDeUnidadDePersistencia");
		
		EntityManager em = entityManagerFactory.createEntityManager();
		EntityTransaction trans = em.getTransaction();
		
		trans.begin();

		Oficina oficina = new Oficina();
		oficina.setIdOficina(1234);
		oficina.setDireccion("Paseo Independencia, 2, 3º B");
		oficina.setTelefono(976652821);

		em.persist(oficina);

		Cliente cliente = new Cliente();
		cliente.setDni("73001517T");
		cliente.setNombre("Juan");
		cliente.setApellidos("Lolo Lulo");
		cliente.setDireccion("Gran Via, 17, 2º A");
		cliente.setEmail("PericodelosPalotes@unizar.es");
		cliente.setTelefono(612345678);
		cliente.setFechaNacimiento(new Date(1992,04,19));

		em.persist(cliente);

		Cliente cliente2 = new Cliente();
		cliente2.setDni("73001515G");
		cliente2.setNombre("Pedro");
		cliente2.setApellidos("Paco Paco");
		cliente2.setDireccion("Via Hispanidad, 15, 5º C");
		cliente2.setEmail("pedrico@unizar.es");
		cliente2.setTelefono(685274196);
		cliente2.setFechaNacimiento(new Date(1972,10,10));

		em.persist(cliente2);

		Cuenta cuenta = new Cuenta();
		cuenta.setnCuenta("12345678901234567890");
		cuenta.setTipo_c(0);
		cuenta.setSaldo(0.0);
		cuenta.setInteres(0.1);
		cuenta.setFecha(new Date(1998,3,1));

		em.persist(cuenta);

		Cuenta cuenta2 = new Cuenta();
		cuenta2.setnCuenta("12345678901234567891");
		cuenta2.setTipo_c(1);
		cuenta2.setSaldo(0.0);
		cuenta2.setOficina(oficina);
		cuenta2.setFecha(new Date(1978,12,5));

		em.persist(cuenta2);

		Set<Cuenta> cuentaList = new HashSet<Cuenta>();
		Set<Cuenta> cuentaList2 = new HashSet<Cuenta>();

		cuentaList.add(cuenta);
		cliente.setListaCuentas(cuentaList);
		em.persist(cliente);

		cuentaList2.add(cuenta);
		cuentaList2.add(cuenta2);
		cliente2.setListaCuentas(cuentaList2);
		em.persist(cliente2);

		Set<Cliente> clienteList = new HashSet<Cliente>();
		Set<Cliente> clienteList2 = new HashSet<Cliente>();

		clienteList.add(cliente);
		clienteList.add(cliente2);
		cuenta.setListaClientes(clienteList);
		em.persist(cuenta);

		clienteList2.add(cliente2);
		cuenta2.setListaClientes(clienteList2);
		em.persist(cuenta2);


		Operacion op = new Operacion();
		op.setC(cuenta);
		op.setCantidad(200);
		op.setDescripcion("Pago del colegio");
		op.setFecha(new Date());
		op.setTipoOperacion(0);
		op.setOficina(oficina);

		em.persist(op);

		trans.commit();

		em.close();
		entityManagerFactory.close();	

		/*Ejecucion consultas*/
		consulta1(em,"12345678901234567891");
		consulta2(em,100);
		consulta3(em,"Pedro",0);
		consulta4(em,500);
		consulta5(em);	
	}

		/* Metodo para la ejecución de la primera consulta de ejemplo, 
	que obtiene la oficina a la que pertenece una cuenta corriente */
	private static Oficina consulta1(EntityManager em, String numCuenta) {
		String consulta1 = "SELECT cc.oficina FROM parte2.Cuenta cc 			WHERE cc.nCuenta = :numCuenta";

		return (Oficina) em.createQuery(consulta1).setParameter("numCuenta", 							numCuenta).getSingleResult();
	}
	/* Metodo para la ejecución de la segunda consulta de ejemplo,
	obtiene las cuentas que posean alguna operacion con importe mayor 
	que una cantidad dada  */
	private static List<Cuenta> consulta2(EntityManager em, float 	cantidad) {
		String consulta2 = "SELECT c FROM parte2.Cuenta c, 					parte2.Operacion o WHERE c.nCuenta = o.cuenta 
			AND o.cantidad > :cant";

		return em.createQuery(consulta2).setParameter("cant", 				cantidad).setMaxResults(100).getResultList();
	}

	/* Obtiene los clientes con un nombre dado que entre sus cuentas 
	tengan alguna con una determinada cantidad*/
	private static List<Cliente> consulta3(EntityManager em, String 	nombre, double cantidad) {
		String consulta3 = "SELECT c FROM parte2.Cliente c JOIN 				c.listaCuentas lc WHERE c.nombre LIKE :nom 
			AND lc.saldo > :cant";

		return em.createQuery(consulta3).setParameter("cant", 				cantidad).setParameter("nom", 							nombre).setMaxResults(100).getResultList();
	}

	/* Consulta que obtiene las cuentas que poseen un saldo superior 
	a una cantidad dada */
	private static List<Cuenta> consulta4(EntityManager em, double 	cantidad) {
		
		CriteriaBuilder cb = em.getCriteriaBuilder();

		CriteriaQuery<Cuenta> q = cb.createQuery(Cuenta.class);		Root<Cuenta> c = q.from(Cuenta.class);
		CriteriaQuery<Cuenta> select = q.select(c);

		ParameterExpression<Double> p = cb.parameter(Double.class);
		select.where(cb.gt((Expression) c.get("saldo"), p));

		TypedQuery<Cuenta> typedQuery = em.createQuery(select);
		typedQuery.setParameter(p, cantidad);

		return typedQuery.getResultList();
	}

	/* Metodo para la quinta consulta, que consiste en obtener la operación
	 que más dinero a movido */
	private static List<Operacion> consulta5(EntityManager em) {
	
		CriteriaBuilder cb = em.getCriteriaBuilder();

		CriteriaQuery<Operacion> q = cb.createQuery(Operacion.class);
		Root<Operacion> c = q.from(Operacion.class);
		CriteriaQuery<Operacion> select = q.select(c);

		select.orderBy(cb.desc(c.get("cantidad")));

		TypedQuery<Operacion> typedQuery = em.createQuery(select);

		return typedQuery.setMaxResults(1).getResultList();
	}
}
