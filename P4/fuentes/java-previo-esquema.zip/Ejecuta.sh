call ant run
pause
