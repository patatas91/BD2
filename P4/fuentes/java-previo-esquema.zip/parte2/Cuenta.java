package parte2;

import java.util.Date;
import java.util.Set;


public class Cuenta {

	private String nCuenta;
	private Set<Cliente> listaClientes;
	private Oficina oficina;
	private Set<Operacion> listaOperaciones;
	
	/*Atributos*/
	private Date fecha;	
	private Double saldo;
	private int tipo_c;
	private Double interes;

	/**
	 * M�todo constructor vac�o 
	 */
	public Cuenta(){
	}
	
	/**
	 * M�todo constructor de la clase
	 */
	public Cuenta(String nCuenta, Date fecha, int tipo_c, double interes) {
		this.nCuenta = nCuenta;
		this.fecha = fecha;
		this.saldo=(double) 0;
		this.tipo_c= tipo_c;
		this.interes = interes;
	}
	
	/**
	 * Devuelve el numero de cuenta
	 * @return int
	 */
	public String getnCuenta()
	{
		return nCuenta;
	}

	/**
	 * Define el numero de cuenta
	 */
	public void setnCuenta(String nCuenta)
	{
		this.nCuenta = nCuenta;
	}
	
	/**
	 * Devuelve la lista de clientes de una cuenta
	 * @return List<Cliente>
	 */
	public Set<Cliente> getListaClientes() {
		return listaClientes;
	}
	
	/**
	 * Define la lista de clientes de una cuenta
	 * @param listaClientes
	 */
	public void setListaClientes(Set<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}
	
	/**
	 * Devuelve la oficina de una cuenta
	 * @return Oficina
	 */
	public Oficina getOficina() {
		return oficina;
	}
	/**
	 * Define la oficina de una cuenta
	 * @param oficina
	 */
	public void setOficina(Oficina oficina) {
		this.oficina = oficina;
	}

	/**
	 * Devuelve un listado de las operaciones de cuenta
	 * @return List<Operacion>
	 */
	public Set<Operacion> getListaOperaciones() {
		return listaOperaciones;
	}
	
	/**
	 * Define una lista de operaciones de una cuenta
	 * @param listaOperaciones
	 */
	public void setListaOperaciones(Set<Operacion> listaOperaciones) {
		this.listaOperaciones = listaOperaciones;
	}
	
	/**
	 * Devuelve la fecha de creacion de una cuenta
	 * @return Date
	 */
	public Date getFecha() {
		return fecha;
	}
	
	/**
	 * Define la fecha de creacion de una cuenta
	 * @param fecha
	 */
	public void setFecha(Date fecha)
	{
		this.fecha = fecha;
	}
	
	/**
	 * Devuelve el saldo de una cuenta
	 * @return double
	 */
	public Double getSaldo() 
	{
		return saldo;
	}
	
	/**
	 * Define el saldo de una cuenta
	 * @param saldo
	 */
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
	/**
	 * Devuelve el tipo de cuenta
	 * @return int
	 */
	public int getTipo_c()
	{
		return tipo_c;
	}
	
	/**
	 * Define el tipo de cuenta
	 * @param tipo_c
	 */
	public void setTipo_c(Integer tipo_c)
	{
		this.tipo_c = tipo_c;
	}
	
	/**
	 * Devuelve el interes de una cuenta
	 * @return double
	 */
	public Double getInteres() 
	{
		return interes;
	}
	
	/**
	 * Define el interes de una cuenta
	 * @param interes
	 */
	public void setInteres(Double interes) 
	{
		this.interes = interes;
	}
	
	/**
	 * Devuelve un String con los datos de cuenta
	 */
	@Override
	public String toString() 
	{
		return("Nº Cuenta: "+nCuenta+", Fecha creacion: "+fecha+", Saldo: "+saldo+
				", Tipo cuenta: "+tipo_c+", Interes: "+interes+", Id oficina: "
				+oficina.getIdOficina());
	
      
    }	

}

