package bd_bancaria;

import java.io.File;
import java.util.List;
import java.util.Scanner;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.query.Predicate;

public class PruebasDb4o extends Util {

	private static final String FICH_CLIENTES = "clientes.txt";
	private static final String FICH_OFICINAS = "oficinas.txt";
	private static final String FICH_CUENTAS = "cuentas.txt";
	private static final String FICH_RELACIONES = "poseer.txt";
	private static final String FICH_OPERACIONES = "operaciones.txt";

	final static String DB_FOLDER = "./DB-FILES";
	// final static String DB_FOLDER = System.getProperty("user.home");

	final static String DB_FILE = "banco.db4o";

	final static String DB4OFILENAME = DB_FOLDER + "/" + DB_FILE;

	public static void main(String[] args) {
		new File(DB4OFILENAME).delete();
		accessDb4o();
		new File(DB4OFILENAME).delete();
		
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		// define que se exploren 2 niveles de profundidad a la hora de guardar
		// (para poder guardar los elementos a los que apunta una referencia)
		configuration.common().objectClass(Cliente.class).updateDepth(2);
		configuration.common().objectClass(Cuenta.class).updateDepth(2);
		
		ObjectContainer db = Db4oEmbedded.openFile(configuration, DB4OFILENAME);
		try {

			/* INSERCIONES */

			insertarClientes(db);
			insertarOficinas(db);
			insertarCuentas(db);
			insertarRelaciones(db);			
			insertarOperaciones(db);

			/* CONSULTAS DE PRUEBA */

			// Todos los clientes
			ObjectSet result = db.queryByExample(Cliente.class);
			listResult(result);

			System.out.println("============================================");

			// Clientes por nombre
			Cliente cli = new Cliente(0, "Ronald", null, null, null, 0, null);
			result = db.queryByExample(cli);
			listResult(result);

			System.out.println("============================================");

			// Clientes con mas de 2 cuentas y menos de 5
			result = db.query(new Predicate<Cliente>() {
				public boolean match(Cliente cli) {
					return cli.getCuentas().size() > 2
							&& cli.getCuentas().size() < 5;
				}
			});
			listResult(result);
			
			System.out.println("============================================");
			// Todas las cuentas
			result = db.queryByExample(Cuenta.class);
			listResult(result);

			
		} finally {
			db.close();
		}
	}

	public static void accessDb4o() {
		ObjectContainer db = Db4oEmbedded.openFile(
				Db4oEmbedded.newConfiguration(), DB4OFILENAME);
		try {
			// do something with db4o
		} finally {
			db.close();
		}
	}

	/**
	 * Busca en la base de datos si existe una cuenta con numero de cuenta igual
	 * a numCuenta. Si existe devuelve una referencia a la cuenta, si no,
	 * devuelve null.
	 * 
	 * @param db
	 *            base de datos donde buscar
	 * @param numCuenta
	 *            numero de cuenta a buscar
	 * @return referencia a la cuenta con ese numero de cuenta (si existe), en
	 *         caso contrario devuelve null.
	 */
	private static Cuenta buscarCuenta(ObjectContainer db, int numCuenta) {
		boolean encontrada = false;
		Cuenta cuenta = null;

		try {
			ObjectSet result = db.queryByExample(new CCorriente(numCuenta, null, 0, 0));
			Cuenta found = (Cuenta) result.next();

			if (found != null) {
				encontrada = true;
				cuenta = found;
			}

		} catch (Exception e) {
			e.getMessage();
		}
		if (!encontrada) {
			try {
				ObjectSet result = db.queryByExample(new CAhorro(numCuenta, null, 0,
						0));
				Cuenta found = (Cuenta) result.next();

				if (found != null) {
					encontrada = true;
					cuenta = found;
				}
			} catch (Exception e) {
				e.getMessage();
			}
		}
		return cuenta;
	}
	
	private static Operacion buscarOperacion(ObjectContainer db, int numOp, 
			int numCuenta) {
		boolean encontrada = false;
		Operacion op = null;

		try {
			ObjectSet result = db.queryByExample(new Transferencia(numCuenta,
					numOp, null, null, 0, 0));
			Operacion found = (Operacion) result.next();

			if (found != null) {
				encontrada = true;
				op = found;
			}

		} catch (Exception e) {
			e.getMessage();
		}
		if (!encontrada) {
			try {
				ObjectSet result = db.queryByExample(new IngresoRetirada(
						numCuenta, numOp, null, null, 0, 0));
				Operacion found = (Operacion) result.next();

				if (found != null) {
					encontrada = true;
					op = found;
				}
			} catch (Exception e) {
				e.getMessage();
			}
		}
		return op;
	}

	public static void insertarClientes(ObjectContainer db) {

		// RESTRICCION :
		// NO SE PUEDEN A�ADIR CLIENTES CON MISMO DNI

		System.out.println("Insertando Clientes...");

		try {
			Scanner scan = new Scanner(new File(FICH_CLIENTES));
			String linea;
			String[] campo;
			while (scan.hasNextLine()) {
				linea = scan.nextLine();
				campo = linea.split(",");

				Cliente cli = new Cliente(Integer.parseInt(campo[0]), campo[1],
						campo[2], campo[3], campo[4],
						Integer.parseInt(campo[5]), campo[6]);

				try {
					Cliente cli2 = new Cliente(Integer.parseInt(campo[0]),
							null, null, null, null, 0, null);
					ObjectSet result = db.queryByExample(cli2);
					Cliente found = (Cliente) result.next();

					System.out.println("Error: Cliente ya existe.");

				} catch (Exception e) {
					db.store(cli);
				}
			}
			scan.close();
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}

	public static void insertarOficinas(ObjectContainer db) {

		// RESTRICCION :
		// NO SE PUEDEN A�ADIR OFICINAS CON MISMO CODIGO

		System.out.println("Insertando Oficinas...");

		try {
			Scanner scan = new Scanner(new File(FICH_OFICINAS));
			String linea;
			String[] campo;
			while (scan.hasNextLine()) {
				linea = scan.nextLine();
				campo = linea.split(",");
				Oficina ofi = new Oficina(Integer.parseInt(campo[0]), campo[1],
						Integer.parseInt(campo[2]));

				Oficina ofi2 = new Oficina(Integer.parseInt(campo[0]), null, 0);
				try {
					ObjectSet result = db.queryByExample(ofi2);
					Oficina found = (Oficina) result.next();
					System.out.println("Error: c�digo de oficina ya existe.");

				} catch (Exception e) {

					db.store(ofi);
				}
			}
			scan.close();
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}

	public static void insertarCuentas(ObjectContainer db) {

		// RESTRICCION :
		// NO SE PUEDEN A�ADIR CUENTAS CON MISMO NUM_CUENTA

		System.out.println("Insertando Cuentas...");

		try {
			Scanner scan = new Scanner(new File(FICH_CUENTAS));
			String linea;
			String[] campo;
			while (scan.hasNextLine()) {
				linea = scan.nextLine();
				campo = linea.split(",");
				Cuenta c = buscarCuenta(db, Integer.parseInt(campo[0]));

				if (c == null) { // comprueba que no existe la cuenta
					if (campo[3].equals("0")) { // CC

						Cuenta cuenta = new CCorriente(Integer.parseInt(campo[0]),
								campo[1], Double.parseDouble(campo[2]),
								Integer.parseInt(campo[5]));
						db.store(cuenta);

					} else { // CA

						Cuenta cuenta = new CAhorro(Integer.parseInt(campo[0]),
								campo[1], Double.parseDouble(campo[2]),
								Float.parseFloat(campo[4]));
						db.store(cuenta);
					}
				} else {
					System.out.println("Error: la cuenta ya existe.");
				}

			}
			scan.close();
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}

	public static void insertarOperaciones(ObjectContainer db) {

		// RESTRICCIONES:
		// NO PUEDEN EXISTIR OPERACIONES ASOCIADAS A UNA CUENTA ANTES DE LA
		// CREACION DE LA MISMA
		// CUENTA ORIGEN DEBE SER UNA CUENTA EXISTENTE
		// CUENTA DESTINO DEBE SER UNA CUENTA EXISTENTE
		// (NUM_CUENTA, OPERAC) DEBE SER UNICO

		System.out.println("Insertando Operaciones...");

		try {
			Scanner scan = new Scanner(new File(FICH_OPERACIONES));
			String linea;
			String[] campo;

			while (scan.hasNextLine()) {
				linea = scan.nextLine();
				campo = linea.split(",");

				Cuenta cuentaOrg = buscarCuenta(db, Integer.parseInt(campo[0]));
				Cuenta cuentaDst = buscarCuenta(db, Integer.parseInt(campo[6]));

				if (cuentaOrg != null) { // cuenta origen existe

					boolean esAnteriorDst = false;
					boolean esAnteriorOrgn = esFechaAnterior(cuentaOrg.getFechaCreacion(),
							campo[2]);

					if (cuentaDst != null) {
						esAnteriorDst = esFechaAnterior(
								cuentaDst.getFechaCreacion(), campo[2]);
					}

					// comprueba que (num_cuenta,num_op) sea unico
					Operacion o = buscarOperacion(db, 
							Integer.parseInt(campo[1]), Integer.parseInt(campo[0]));
					
					if (campo[5].equals("0") && esAnteriorOrgn && esAnteriorDst) {
						
						// Transferencia
						if (o == null){
//							System.out.println("Transferencia valida , cuenta->"
//									+ cuentaOrg);
							Operacion op = new Transferencia(
									Integer.parseInt(campo[0]),
									Integer.parseInt(campo[1]), campo[2], campo[3],
									Double.parseDouble(campo[4]),
									Integer.parseInt(campo[6]));
							db.store(op);
						}  else { //(num_cuenta, num_op) debe ser unico
//							System.out.println("Error: Operacion invalida.");
						}
	
					} else if ((campo[5].equals("1") || campo[5].equals("2"))
							&& esAnteriorOrgn) {
						
						// Ingreso-Retirada
						if (o == null){
//							System.out.println("Ing/ret valida, cuentaorgn->"
//									+ cuentaOrg + " cuentadest->" + cuentaDst);
							Operacion op = new IngresoRetirada(
									Integer.parseInt(campo[0]),
									Integer.parseInt(campo[1]), campo[2], campo[3],
									Double.parseDouble(campo[4]),
									Integer.parseInt(campo[7]));
							db.store(op);
							
						} else { //(num_cuenta, num_op) debe ser unico
//							System.out.println("Error: Operacion invalida.");
						}					
					} else {
//						System.out.println("Error: Operacion invalida.");
					}
				} else { // cuentaOrgn no existe
//					System.out.println("Error: Operacion invalida.");
				}
			}
			scan.close();
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}

	public static void insertarRelaciones(ObjectContainer db) {

		// RESTRICCIONES:
		// CLIENTE DEBE SER UN CLIENTE EXISTENTE
		// NUM_CUENTA DEBE SER UNA CUENTA EXISTENTE

		System.out.println("Relacionando Clientes y Cuentas...");
		try {
			Scanner scan = new Scanner(new File(FICH_RELACIONES));
			String linea;
			String[] campo;
			while (scan.hasNextLine()) {
				linea = scan.nextLine();
				campo = linea.split(",");
				try {
					// Localiza el cliente y le asocia la cuenta si la tiene
					ObjectSet result = db.queryByExample(new Cliente(Integer
							.parseInt(campo[0]), null, null, null, null, 0,
							null));
					Cliente found = (Cliente) result.next();

					// comprueba que cuenta existe
					Cuenta c = buscarCuenta(db, Integer.parseInt(campo[1]));

					if (c != null) {
						found.setCuenta(Integer.parseInt(campo[1]));
						c.setTitular(found);
						db.store(found);
						db.store(c);
						System.out.println("Cliente " + found.getNombre()
								+ " asociado a cuenta" + c.getNumCuenta());
					} else {
						System.out.println("Error: Cuenta no valida");
					}

				} catch (Exception e) {
					System.out.println("Error: Cliente no valido."+ e.getMessage());
				}

			}
			scan.close();
		} catch (Exception e) {
			e.printStackTrace();
			e.getMessage();
		}

	}

}
