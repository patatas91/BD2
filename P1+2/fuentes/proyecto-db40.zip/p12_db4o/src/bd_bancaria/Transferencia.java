package bd_bancaria;

public class Transferencia extends Operacion {

	private int destino;
	
	public Transferencia(int o, int n, String f, String d, double c, int de) {
		super(o, n, f, d, c);
		super.setTipoOp(0);
		destino = de;
	}

	public int getDestino(){
		return destino;
	}

	public String toString() {
		return "Transferencia: [" + super.getOrigen() + "->" + getDestino()
				+ "] "+ super.getCantidad() + "euros. Op:" + super.getOperacion() + " Descripcion:" 
				+ super.getDescripcion();
	}
}
