package bd_bancaria;

import java.util.ArrayList;
import java.util.Iterator;

public class Cuenta {
		
	private int nCuenta;
	private String fecha;
	private double saldo;
	private ArrayList<Cliente> titulares;

	
	public Cuenta(int c, String f){
		nCuenta = c;
		fecha = f;
		saldo = 0;
		titulares = new ArrayList<Cliente>();
	}
	
	public int getNumCuenta(){
		return nCuenta;
	}

	public String getFechaCreacion(){
		return fecha;
	}
	
	public double getSaldo(){
		return saldo;
	}
	
	public void setSaldo(double s){
		saldo = saldo + s;
	}
	
	public boolean setTitular(Cliente cli){
		return titulares.add(cli);
	}
	
	public String getTitulares(){
		Iterator<Cliente> it = titulares.iterator();
		String titulares = " ";
		
		while(it.hasNext()){
			titulares += it.next().getDni() + " " ;
		}
		
		return titulares;
	}
	
	public boolean equals(Cuenta c){
		return (nCuenta == c.getNumCuenta());
	}
}
