package bd_bancaria;

public class CCorriente extends Cuenta {

	private int idOficina;
	
	public CCorriente(int c, String f, int o) {
		super(c, f);
		idOficina = o;
	}
	
	/**
	 * Metodo creado para poder realizar las inserciones desde fichero (cuentas
	 * con un saldo diferente de 0)
	 */
	public CCorriente (int c, String f, double s, int o){
		super(c, f);
		idOficina = o;
		super.setSaldo(s);
	}

	public int getOficina(){
		return idOficina;
	}
	
	public String toString(){
		return super.getNumCuenta() + ". Fecha de creacion:" + super.getFechaCreacion() + 
				". Oficina: " + idOficina + " tiene saldo de: " + super.getSaldo();
	}
}
