package bd_bancaria;

/**
 * Example extracted and adapted from http://community.versant.com/documentation/reference/db4o-8.0/java/tutorial/docs/FirstGlance.html
 * Date: March 15, 2014
 */

import java.util.*;

public class Util {

	public static void listResult(List<?> result) {
		System.out.println(result.size());
		for (Object o : result) {
			System.out.println(o);
		}
	}

	/**
	 * Metodo que compara si una fecha expresada como una cadena de caracteres
	 * es anterior que otra.
	 * Las fechas deben ser cadenas de caracteres y cumplir el siguiente 
	 * formato:
	 * 		aaaa-mm-dd	(Ej: 2015-03-15)
	 * 
	 * @param f1 Fecha
	 * @param f2 Fecha
	 * @return true si la fecha f1 es estrictamente anterior a f2
	 */
	public static boolean esFechaAnterior (String f1, String f2){
	
		String[] fecha1 = f1.split("-");
		String[] fecha2 = f2.split("-");
		
		boolean anterior = false;
		
		int[] dato1 = new int[fecha1.length], dato2 = new int[fecha2.length];
			
		for(int i=0; (i < fecha1.length) ; i++){

			dato1[i] = Integer.parseInt(fecha1[i]);
			dato2[i] = Integer.parseInt(fecha2[i]);
		}	
		
		anterior = dato1[0]<dato2[0] || dato1[0] == dato2[0] && 
				dato1[1]<dato2[1] || dato1[0] == dato2[0] &&
						dato1[1] == dato2[1] && dato1[2]<dato2[2];
		return anterior;
		
	}

}
