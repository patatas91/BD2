package bd_bancaria;

public class CAhorro extends Cuenta {

	private float interes;
	
	public CAhorro(int c, String f, float i) {
		super(c, f);
		interes = i;
	}
	
	/**
	 * Metodo creado para poder realizar las inserciones desde fichero (cuentas
	 * con un saldo diferente de 0)
	 */
	public CAhorro(int c, String f, double s, float i) {
		super(c, f);
		interes = i;
		super.setSaldo(s);
	}

	public float getInteres(){
		return interes;
	}
	
	public String toString(){
		return super.getNumCuenta() + " tiene un saldo de: " + super.getSaldo() 
				+ " y un interes de " + interes;
	}
}
