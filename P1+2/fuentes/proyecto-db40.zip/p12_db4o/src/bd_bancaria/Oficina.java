package bd_bancaria;

public class Oficina {
	
	private int idOficina;
	private String direccion;
	private int telefono;
	
	public Oficina(int id, String dir, int tlf){
		idOficina = id;
		direccion = dir;
		telefono = tlf;
	}
	
	public int getId() {
		return idOficina;
	}
	
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String dir) {
		direccion = dir;
	}
	
	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int tlf) {
		telefono = tlf;
	}
	
	public String toString(){
		return idOficina + " " + direccion + " " + telefono;
	}
}
