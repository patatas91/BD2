package bd_bancaria;

public class IngresoRetirada extends Operacion{

	private int idOficina;
	
	public IngresoRetirada(int o, int n, String f, String d, double c, int i) {
		super(o, n, f, d, c);
		if(c>0){
			//Ingreso
			super.setTipoOp(1);
		}
		else{
			//Retirada
			super.setTipoOp(2);
		}
		idOficina = i;
	}
		
	public int getOficina(){
		return idOficina;
	}
	
	public String toString(){
		return "Ingreso/Retirada: [" + super.getOrigen() + "] "+ getCantidad() 
				+ "euros. Op:" + super.getOperacion() + " Desc:" 
				+ super.getDescripcion() + " Oficina:" + getOficina() ;
	}
}
