package bd_bancaria;

import java.util.ArrayList;

public class Cliente {

	private int dni;
	private String nombre;
	private String apellidos;
	private String direccion;
	private String email;
	private int telefono;
	private String fechaNacimiento;
	private ArrayList<Integer> cuentas;
	
	public Cliente(int d, String nom, String ap, String dir, String e, int telf, String fecha) {
		dni = d;
		nombre = nom;
		apellidos= ap;
		direccion= dir;
		email = e;
		telefono = telf;
		fechaNacimiento = fecha;
		cuentas = new ArrayList<Integer>();
	}
	
	public int getDni(){
		return dni;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellidos(){
		return apellidos;
	}
	
	public String getDireccion(){
		return direccion;
	}
	
	public void setDireccion(String nuevaDir){
		direccion = nuevaDir;
	}
	
	public String getEmail(){
		return email;
	}
	
	public void setEmail(String nuevoEmail){
		email = nuevoEmail;
	}
	
	public int getTelefono(){
		return telefono;
	}
	
	public void setTelefono(int nuevoTelf){
		telefono = nuevoTelf;
	}

	public String getFecha(){
		return fechaNacimiento;
	}
	
	public ArrayList<Integer> getCuentas(){
		return cuentas;
	}
	public boolean setCuenta(Integer c){
		return cuentas.add(c);
	}
	
	public boolean equals (Cliente c){
		return (dni == c.getDni());
	}
	
	public String toString() {
		return dni + " " + nombre + " " + apellidos + " " + direccion + " " + email + 
				" " + telefono + " " + fechaNacimiento;
	}
}
