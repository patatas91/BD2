package bd_bancaria;

public class Operacion {
	private int nOperacion;
	private String fechaHora;
	private double cantidad;
	private String descripcion;
	private int origen;
	private int tipo_op;
	
	public Operacion(int o, int n, String f, String d, double c){
		nOperacion = n;
		fechaHora = f;
		cantidad = c;
		descripcion = d;
		origen = o;
	}
	
	public int getOperacion(){
		return nOperacion;
	}
	
	public String getFecha(){
		return fechaHora;
	}
	
	public double getCantidad(){
		return cantidad;
	}
	
	public String getDescripcion(){
		return descripcion;
	}
	
	public int getOrigen(){
		return origen;
	}
	
	/*
	 * 0 = transferencia, 1 = ingreso, 2 = retirada
	 */
	public void setTipoOp(int t){
		tipo_op = t;
	}
	
	public int getTipoOp(){
		return tipo_op;
	}
}
